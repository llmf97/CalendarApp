/**
 * @summary Compares two dates using moment library
 * @param a
 * @param b
 * @return {*}
 */
function compareDates(a,b){
	return moment(a).isSame(moment(b));
}

// These are the displayed date ranges
var startDate = new ReactiveVar(new Date(), compareDates);
var endDate = new ReactiveVar(new Date(), compareDates);

Template.myCalendar.onCreated(function(){
	var self = this;
        // (Re-)subscribe to published events when the start and end date changes
	self.autorun(function(){
		self.subscribe('events', startDate.get(), endDate.get());
	});
});

Template.myCalendar.helpers({
	options: function () {
		return {
                        header:{
                        center: 'month,agendaWeek,agendaDay',},
                        defaultView:     'agendaWeek',
                        height:           550,
                        id:              'cal',        // DOM id
			editable:         true,
			startEditable:    true,
			durationEditable: true,
                        events:           events,
			eventClick:       eventClick,
                        dayClick:         dayClick,
			eventResize:      eventResize,
			eventDrop:        eventDrop,
			autoruns:         [
				function () {
					//monitors the events collection and run reactively
					Events.find().fetch();
				}
			]
		};
	}
});

/**
 * FullCalendar events() method
 * See: http://fullcalendar.io/docs/event_data/events_function/
 *
 * This function can be called in 2 different ways:
 *   * When fullcalendar needs event data
 *   * When the underlying collection reactively updates
 */
function events(fStart, fEnd, timezone, callback) {
	// Convert the dates to JavaScript dates.
	  var start = fStart.toDate(),
		end = fEnd.toDate();

	// If the start and end dates have been altered then update the subscription.
	// Changing startDate or endDate will cause the subscription above to rerun,
	// which in turn updates what's in the collection, which in turn reruns this
	// events() function.
	startDate.set(start);
	endDate.set(end);

	// Return the currently requested events
	var eventsResult = Events.find({
		$or: [{
			start: { $gte: start, $lt: end }
		},{
			end: { $gte: start, $lt: end }
		}]
	}).fetch();

	callback(eventsResult);
}

/**
 * FullCalendar eventClick() method
 * See: http://fullcalendar.io/docs/mouse/eventClick/
 */
function eventClick(ev, jsEv, view) {
	// Can remove the event when clicked on it, if requested.
   var edit = prompt("If you wish to remove the entry, press r ","");
   if(edit == 'r'){  
	Events.remove({
		_id: ev._id
	});
    }
  }

/**
 * FullCalendar dayClick() method
 * See: http://fullcalendar.io/docs/mouse/dayClick/
 */
function dayClick(date, jsEv, view) {
    var enter = prompt("If you wish to make an entry please press y ","");
    if (enter == 'y'){
	// The date here is a moment() which has no time component.
	// See: http://fullcalendar.io/docs/utilities/Moment/#ambiguously-zoned
	// The date is adjusted by converting it to ISO8601, then back to moment, then to a date
	var adjDate = moment(date.toISOString()).toDate();
	// Inserts an event on the day that was clicked.
	Events.insert(generateEvent(adjDate));
       }
}

/**
 * FullCalendar eventResize() method
 * See: http://fullcalendar.io/docs/event_ui/eventResize/
 */
function eventResize(ev, delta, revertFunc) {
	// See dayClick() 
	var adjStartDate = moment(ev.start.toISOString()).toDate();
	var adjEndDate = moment(ev.end.toISOString()).toDate();

	// Update the database
	Events.update({
		_id:ev._id
	},{
		$set: {
			end: (ev.end) ? adjEndDate : adjStartDate
		}
	},function(err){
		// Call revert if there is an error updating the database
		if (err) revertFunc();
	});
}

/**
 * FullCalendar eventDrop() method
 * See: http://fullcalendar.io/docs/event_ui/eventDrop/
 */
function eventDrop(ev, delta, revertFunc, jsEv, ui, view) {
	// See dayClick() for adjustment to dates
	var adjStartDate = moment(ev.start.toISOString()).toDate();
	var updateObject = {
		start: adjStartDate
	};

	if (ev.end) {
		updateObject.end = moment(ev.end.toISOString()).toDate();
	}

	// Update the database
	Events.update({
		_id:ev._id
	},{
		$set: updateObject
	}, function(err){
		// Call revert if there is an error updating the database
		if (err) revertFunc();
	});
}

/**
 * Generate a  FullCalendar event
 * @param {date} date
 * @return {object}
 */
function generateEvent(date) {
        var name = prompt("Please enter the title of the event ","");
	var details = prompt("Please give a brief description of the event ","");
        return {
		title: [name, details], 
		start: date,
		allDay: false,
		backgroundColor: selectColor()
	}
}

/**
 * Select a hex color
 * return selected color
 */
function selectColor() {
      var priority = prompt("Please enter importance of event\n1,2 or 3 ","");
        var color; 
	if (priority == 1){
            color = '#cc0000';}
        else if (priority == 2){
            color = '#ffce61';}
        else {color = '#e4dfdf';}
	return color;
}
